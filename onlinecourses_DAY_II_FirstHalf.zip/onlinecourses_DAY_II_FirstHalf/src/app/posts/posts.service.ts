import { HttpClient } from '@angular/common/http';

export class PostsService{

    constructor(public httpServObj:HttpClient){

}    
getAllPosts(){
        // make AJAX request !
        // HttpClient (Service)
        this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
            console.log(response);
        })
      
    }
}