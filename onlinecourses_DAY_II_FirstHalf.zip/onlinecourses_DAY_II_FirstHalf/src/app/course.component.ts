import {Component, Input} from '@angular/core';
import { CourseModel } from './course.model';
import { CourseService } from './course.service';

@Component(
    {
        selector:`app-course`,
       templateUrl:`./course.component.html`,
       styleUrls:["./course.style.css"]
    }
)

export class CourseComponent{
        @Input() coursedetails:CourseModel=
        new CourseModel();
        isFree:boolean=false;

        constructor(public servObj:CourseService){

        }

        DeleteCourseItem(){
                this.servObj.deleteACourse(this.coursedetails.id);
        }
}

