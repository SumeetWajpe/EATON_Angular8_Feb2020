import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'

import { AppComponent } from './app.component';
import { CourseComponent } from './course.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';
import { DurationPipe } from './duration.pipe';
import { CourseService } from './course.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts/posts.service';

@NgModule({
  declarations: [
    AppComponent,CourseComponent,
     ListofcoursesComponent, DurationPipe, PostsComponent
  ],
  imports: [
    BrowserModule,FormsModule,
     BrowserAnimationsModule,MatCheckboxModule,
     HttpClientModule
  ],
  providers:[CourseService,PostsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
