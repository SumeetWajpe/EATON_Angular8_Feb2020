import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent implements OnInit {
 headerImage:string="https://dailysmarty-production.s3.amazonaws.com/uploads/post/img/522/feature_thumb_angular-card.png";
 heading:string="Online Courses";
  courses:CourseModel[]=[];

  constructor(public servObj:CourseService) {
    this.courses = this.servObj.listofcourses;
   }

  ngOnInit() {
  }

  ChangeHeading(){
    this.heading = "Udemy !";
  }

  ChangeHeadingOnInput(evt){
    this.heading = (evt.target.value)
  }

}
