export class CourseModel{
    constructor(
        public id?:number,
        public name?:string,
        public duration?:number,
        public price?:number,
        public rating?:number,
        public ImageUrl?:string,
        public likes?:number
        ){
 
    }
 }