import {Component, Input} from '@angular/core';
import { CourseModel } from './course.model';

@Component(
    {
        selector:`app-course`,
       templateUrl:`./course.component.html`,
       styleUrls:["./course.style.css"]
    }
)

export class CourseComponent{
        @Input() coursedetails:CourseModel=
        new CourseModel();
}

