import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CourseComponent } from './course.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';

@NgModule({
  declarations: [
    AppComponent,CourseComponent, ListofcoursesComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
