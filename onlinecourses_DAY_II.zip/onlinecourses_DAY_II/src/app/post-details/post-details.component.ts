import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {

  thePost:any={};
  constructor(public currRoute:ActivatedRoute,
    public postServObj:PostsService) {

    this.currRoute.params.subscribe(
      p=> {
      this.thePost = 
      this.postServObj.postsFromService.find(currPost=>
         currPost.id == p.id);
      
      }
    )
   }

  ngOnInit() {
  }

}
