import { CourseModel } from './course.model';
export class CourseService {
    listofcourses: CourseModel[] = [
        {id:1, name: "Typescript", duration: 2, rating: 5, price: 0, likes: 400, ImageUrl: "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fmspoweruser.com%2Fwp-content%2Fuploads%2F2016%2F07%2Ftypescript-cover-image.jpg&f=1" },
        { id:2, name: "Angular", duration: 2, rating: 4, price: 4000, likes: 400, ImageUrl: "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fjaxenter.com%2Fwp-content%2Fuploads%2F2016%2F01%2Fshutterstock_229869889.jpg&f=1" },
        {id:3,  name: "Vue", duration: 2, rating: 4.678, price: 8000, likes: 300, ImageUrl: "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.programwitherik.com%2Fcontent%2Fimages%2F2017%2F01%2F87ow.png&f=1" },
        { id:4, name: "Redux", duration: 5, rating: 3, price: 6000, likes: 200, ImageUrl: "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fblog.js-republic.com%2Fwp-content%2Fuploads%2F2016%2F11%2Flogo-redux.png&f=1" },
        {id:5,  name: "React", duration: 3, rating: 4, price: 5000, likes: 100, ImageUrl: "https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.valuecoders.com%2Fblog%2Fwp-content%2Fuploads%2F2016%2F08%2Freact.png&f=1" },
    ];
    getAllCourses():CourseModel[] {
        return this.listofcourses;
    }

    deleteACourse(id:number):void{
        // logic for deleting an item !
        let index = this.listofcourses.findIndex(c=> c.id == id);
        this.listofcourses.splice(index,1);
    }

}