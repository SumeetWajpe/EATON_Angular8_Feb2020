import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { CourseComponent } from './course.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';
import { DurationPipe } from './duration.pipe';
import { CourseService } from './course.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts/posts.service';
import { from } from 'rxjs';
import { PostDetailsComponent } from './post-details/post-details.component';
import { DashboardComponent } from './dashboard/dashboard.component';

// const routes:Routes = [
//   {path:'',component:ListofcoursesComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'postdetails/:id',component:PostDetailsComponent},
//   {path:'**',redirectTo:'/'}
// ];


const routes:Routes = [
{path:"dashboard",component:DashboardComponent,
children:[
  {path:'',component:ListofcoursesComponent},
  {path:'posts',component:PostsComponent},
  {path:'postdetails/:id',component:PostDetailsComponent},
]}
]


@NgModule({
  declarations: [
    AppComponent,CourseComponent,
     ListofcoursesComponent, DurationPipe, PostsComponent, PostDetailsComponent, DashboardComponent
  ],
  imports: [
    BrowserModule,FormsModule,
     BrowserAnimationsModule,MatCheckboxModule,
     HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers:[CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
