import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  allposts:any = [];

  constructor(public postServObj:PostsService) {
    // Using Observables !
    //   let postObservable =this.postServObj.getAllPosts();
    //   postObservable.subscribe((response)=>{
    //    this.allposts = response;
    // });

    let aPromise = this.postServObj.getAllPosts();
    aPromise.then(response=>{
      this.allposts = response;
      this.postServObj.postsFromService = response;
    
    },
      err=>console.log(err))
   }

  ngOnInit() {
  }

}
