import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root' // injected in root module (AppModule here)
})
export class PostsService {
    postsFromService :any = [];
    constructor(public httpServObj: HttpClient) { }

    // Using Observables !
    // getAllPosts(){
    //         // make AJAX request !
    //         // HttpClient (Service)
    //       return  this.httpServObj.get('https://jsonplaceholder.typicode.com/posts');

    //     }

    getAllPosts() {
     return   this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    }
}